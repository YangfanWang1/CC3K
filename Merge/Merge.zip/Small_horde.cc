#include "Small_horde.h"

Small::Small():
    Treasure{2}
{}
