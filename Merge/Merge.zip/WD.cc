#include "WD.h"

WD::WD():Potion{"Wound Def"}{}

void WD::apply(Player* PC){
    PC->setDEF(PC->getDEF()-10);
    kill();
}
