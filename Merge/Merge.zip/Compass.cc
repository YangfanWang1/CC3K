#include "Compass.h"
class Cell;


Compass::Compass(Cell* stair):stair{stair}{}

//check if user on the same pos of compass, if so, make stair cell appear, and unwind compass from cell
void Compass::acquire(Player* PC){
        stair->reveal();
        kill();
    }
