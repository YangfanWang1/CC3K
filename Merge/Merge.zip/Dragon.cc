# include "Dragon.h"
using  namespace std;

Dragon::Dragon(int HP,int ATK,int DEF, Entity* protector, bool hard,Cell* currentCell, bool compassHolder){};

Cell* Dragon::setAggroTrigger(){};

void Dragon::moveRandom(){};

void Dragon::attackPlayer(Player*){};

void Dragon::create_barrier(){};

Dragon::~Dragon(){};
