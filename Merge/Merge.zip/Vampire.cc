# include "Vampire.h"
using namespace std;

Vampire::Vampire(int HP,int ATK,int DEF, Entity* protector, bool hard,Cell* currentCell, bool compassHolder){};

void Vampire::attackPlayer(Player*){};

Vampire::~Vampire(){};
