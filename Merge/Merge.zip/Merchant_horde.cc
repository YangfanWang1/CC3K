#include "Merchant_horde.h"


Merchant_horde::Merchant_horde():
    Treasure{4}
{}
