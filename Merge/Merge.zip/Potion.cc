#include "Potion.h"
#include <string>
Potion::Potion(std::string type,bool used):type{type},used{used}{}

void Potion::set_used(bool used){
    this->used=used;
}



