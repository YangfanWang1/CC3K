# include "Player.h"
# include "Enemy.h"
# include "Treasure.h"
# include <math.h>
using namespace std;

void Player::collectTreasure(Treasure* t){
    gold += t->getValue();
};

void Player::setBarrier(bool a){
    barrier_suit = a;
};

int Player::getGold(){
    return gold;
};

void Player::setGold(int n){
    gold = n;
};

void Player::attackEnemy(Enemy *e){
    int enemy_damage = ceil((100.0 / (100.0 + e->getDEF())) * ATK);
    int enemy_HP_bef = e->getHP();
    e->setHP(enemy_HP_bef-enemy_damage);
};

void Player::kill(){};

Player::~Player(){};

