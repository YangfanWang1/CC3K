# ifndef PLAYER_H
# define PLAYER_H
# include "Enemy.h"
# include "Treasure.h"
# include <string>
# include <memory>
# include <vector>
# include <string>
# include "Entity.h"
class Entity;
class Potion;

class Player : public Entity{
    protected:
        std::vector<std::string> usedPotionTypes;
        bool barrier_suit;
        int baseatk;
        int basedef;
        int def;
        int maxhp;
        int gold;
    public:
        // modify my treasure
        void collectTreasure(Treasure* t);
        void setBarrier(bool a);
        int getGold();
        void setGold(int n);
        void attackEnemy(Enemy *e);
        void kill();
        virtual ~Player() = 0;
};

# endif
