#include "Normal_horde.h"

//worth of 1
Normal::Normal():
    Treasure{1}
{}
