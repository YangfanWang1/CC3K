#include "PH.h"
class Player;

PH::PH():Potion{"Poison Health"}{}


//potion is diffent, after kill that makes it unwind from cell, it will call dtor by itself.
void PH::apply(Player* PC){
    PC->setHP(PC->getHP()-10);
    kill();
}
