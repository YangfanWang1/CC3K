# include "Dwarf.h"

Dwarf::Dwarf(int HP,int ATK,int DEF, Entity* protector, bool hard,Cell* currentCell){};

Dwarf::~Dwarf(){};
