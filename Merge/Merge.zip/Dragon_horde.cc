#include "Dragon_horde.h"

Dragon_horde::Dragon_horde():
    Treasure{6}
{}
