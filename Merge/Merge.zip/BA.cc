#include "BA.h"
class Player;

BA::BA():Potion{"Boost ATK"}{}
void BA::apply(Player* PC){
    PC->setATK(PC->getATK()+10);
    kill();
}
