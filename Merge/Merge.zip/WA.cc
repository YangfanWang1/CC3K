#include "WA.h"
class Player;

WA::WA():Potion{"Wound ATK"}{}

void WA::apply(Player* PC){
    PC->setATK(PC->getATK()-10);
    kill();
}
