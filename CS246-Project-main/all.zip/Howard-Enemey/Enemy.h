# ifndef ENEMY_H
# define ENEMY_H

# include <string>
# include <memory>
#include "Entity.h"


/* Note, entity has the static field of random gengeration of seed, and this will be the seed for all it's subclass, currently, only when one of the concerete enemy class's update() will increment the seed, I am choosing enemy now, so whenever this update get called, it's generating with different seed. 
 */

class Player;
class Cell;

class Enemy:public Entity{
    protected:
        Cell* stair;
    public:
        Enemy(int HP,int ATK,int DEF,Entity* protector,bool hard,Cell* currentCell,Cell* );
        // only dragon overrides
        virtual void moveRandom();
        virtual void attackPlayer(Player*);
        void update();
        void kill(Player* PC)override;
        virtual ~Enemy() = 0;
};

# endif
