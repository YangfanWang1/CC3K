# include "Merchant.h"
#include <iostream>
bool Merchant::M_hostile = false;

Merchant::Merchant(int HP,int ATK,int DEF, Entity* protector, bool hard,Cell* currentCell, Cell* stair):
                    Enemy{HP,ATK,DEF,protector,hard,currentCell,compassHolder}{
    HP = 30;
    ATK = 70;
    DEF = 5;
    protector = nullptr;
}
string Merchant::getType(){
    return "Merchant";
}
void Merchant::set_hostile(bool hostile){
    M_hostile=hostile;
}

ostream& Merchant::operator<<(ostream& out, Merchant& m){
             out<<"M";
            return out;
        }

void Merchant::update(){
    Entity::seed++;
    if(M-hostile==true){
    for(int i=0; i < currentCell->getBlock().size();i++){
        if((getType()=="Player")){
                attackPlayer(currentCell->getBlock().at(i));
                return;
}}
}
    moveRandom();
    };

void purchasePotion(Player* PC, string Potion){
    std::cout<<"yooooo, merchant can't sell now!"<<endl;
}
Merchant::~Merchant(){};
