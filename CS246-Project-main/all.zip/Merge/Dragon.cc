# include "Dragon.h"
# include "Barrier.h"
# include "Compass.h"
using  namespace std;

Dragon::Dragon(bool hard,Cell* currentCell, Cell* stair):
Enemy{150,20,20,nullptr,hard,currentCell,stair}{
    //check dragonhorde nearby, and set protector
    //set Aggrotrigger
    for(int i=0; i < currentCell->getWalkableBlock().size();i++){
        if(currentCell->getWalkableBlock().at(i)->getEntity()->getType()=="DragonHorde"){
            setAggroTrigger(currentCell->getWalkableBlock().at(i));
            currentCell->getWalkableBlock().at(i)->getEntity()->setProtector(this);
        }
    }
}

void Dragon::setAggroTrigger(Cell *cell){
    aggroTrigger = cell;
};

// deleted
//void Dragon::create_barrier(){
    //for(int i =0;i<currentCell->getBlock().size();i++){
        //if(currentCell->getBlock().at(i)->getEntity() == nullptr){
            //break;
        //}
        //if(i == currentCell->getBlock().size()-1){
            //return;
        //}
    //}
    ////have an avilable spot to place
    //vector<Cell*> block = currentCell->getBlock();
    //int dir = rand(seed)%block.size();
    ////not sure what v is here
    ////int dir = rand(seed)%v.size();

    //// pick a direction and try to move first
    //Cell* potential = block[dir];
    //// if that direction is occupied, picks another direction
    //while(potential->getEntity() != nullptr){
        //dir=rand(seed)%block.size();
        ////dir=rand(seed)%v.size();
        //potential = block[dir];
    //}
    //// place barrier at potential
    //potential->setEntity(make_shared<Barrier>());
//};


void Dragon::update(){
    Entity::seed++;
    for(int i=0; i < aggroTrigger->getBlock().size();i++){
        if(aggroTrigger->getBlock().at(i)->getEntity()->getType()=="Player"){
            // shared pointer and pointer?
            // check if dragon dies or not
            Entity* temp_entity = (currentCell->getBlock().at(i)->getEntity().get());
            Player* PC = dynamic_cast<Player*>(temp_entity);
            if(HP <= 0){
                kill(PC);
            }
            else{
                attackPlayer(PC);
            }
            return;
        }
    }
}

void Dragon::kill(Player* pc){
    if(this->getHP()<=0){
        setHP(0);
    // no gold
    //unwind myself from cell;
    currentCell->setEntity(nullptr);
    // set dragon horde's protector to nullptr
    // dragonhorde and barrier should have a getType
    for(int i=0; i < currentCell->getWalkableBlock().size();i++){
        if(currentCell->getWalkableBlock().at(i)->getEntity()->getType()=="DragonHorde"){
            currentCell->getWalkableBlock().at(i)->getEntity()->setProtector(nullptr);
        }
        if(currentCell->getWalkableBlock().at(i)->getEntity()->getType()=="Barrier"){
            currentCell->getWalkableBlock().at(i)->getEntity()->setProtector(nullptr);
        }
    }
    //if I'm compass holder:
    if (stair != nullptr) {
        currentCell->setEntity(make_shared<Entity>(Compass(stair)));
    }
    else{
        return;
    }
};

Dragon::~Dragon(){};
