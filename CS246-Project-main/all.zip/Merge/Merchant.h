#ifndef MERCHANT_H
#define MERCHANT_H
#include <string>
#include "Compass.h"
#include "Enemy.h"

class Merchant : public Enemy {
    static bool M_hostile;

   public:
    Merchant(bool hard, Cell* currentCell, Cell* stair);
    void set_hostile(bool hostile);
    void update() override;
    void purchasePotion(Player* PC, std::string Potion);
    std::string getType() override;
    friend std::ostream& operator<<(std::ostream& out, Merchant& m);
    ~Merchant() = default;
    void kill() override;
};

#endif
