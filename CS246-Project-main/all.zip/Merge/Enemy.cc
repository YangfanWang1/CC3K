#include "Enemy.h"

#include <math.h>

#include <algorithm>
#include <memory>

#include "Compass.h"
#include "Entity.h"
#include "Player.h"

using namespace std;

Enemy::Enemy(int HP, int ATK, int DEF, Entity* protector, bool hard, Cell* currentCell, Cell* stair) : Entity(HP, ATK, DEF, protector, hard, currentCell), stair{stair} {}

void Enemy::moveRandom() {
    // check if all block is full,if full, return
    for (int i = 0; i < currentCell->getWalkableBlock().size(); i++) {
        if (currentCell->getWalkableBlock().at(i)->getEntity() == nullptr) {
            break;
        }
        if (i == currentCell->getWalkableBlock().size() - 1) {
            return;
        }
    }
    // have an avilable spot to move
    vector<Cell*> block = currentCell->getWalkableBlock();
    srand(seed);
    int dir = rand() % block.size();
    // not sure what v is here
    // int dir = rand(seed)%v.size();
    seed++;
    srand(seed);
    // pick a direction and try to move first
    Cell* next_cell = block[dir];
    // if that direction is occupied, pick another direction
    while (next_cell->getEntity() != nullptr) {
        dir = rand() % block.size();
        // dir=rand(seed)%v.size();
        next_cell = block[dir];
    }
    currentCell->transferEntity(next_cell);
};
//// not finished, could be wrong
// void Enemy::moveRandom(){
// currentCell->setEntity(nullptr);
// vector<Cell*> block = currentCell->getBlock();
// std::vector<int> v = { 1, 2, 3, 4};
// std::shuffle( v.begin(), v.end(), 341);
// int dir = v[0];
//// pick a direction and try to move first
// Cell* next_cell = block[dir];
//// if that direction is occupied, picks another direction
// while(next_cell->getEntity() != nullptr){
// std::shuffle( v.begin(), v.end(), 341);
// dir = v[0];
// next_cell = block[dir];
//}
// currentCell = next_cell;
////currentCell->setEntity(shared_ptr<*this>);
//};

// dragon should override, merchant check hostile
// 50 percent chance of missing
void Enemy::attackPlayer(Player* pc) {
    // choose a number, 0 or 1
    seed++;
    srand(seed);
    int status = rand() % 2;
    // attack if 0
    if (status == 0) {
        // if player has no barrier
        // cast entity pointer to player pointer
        if (!pc->getBarrier()) {
            int player_damage = ceil((100.0 / (100.0 + pc->getDEF())) * ATK);
            int player_HP_before = pc->getHP();
            pc->setHP(player_HP_before - player_damage);
        } else {
            int player_damage = ceil(ceil((100.0 / (100.0 + pc->getDEF())) * ATK)) / 2;
            int player_HP_before = pc->getHP();
            pc->setHP(player_HP_before - player_damage);
        }
    } else {
        return;
    }
};

// we check is player within the range or not first, if so then attack directly, and not move. otherwise randome moving
void Enemy::update() {
    Entity::seed++;
    for (int i = 0; i < currentCell->getBlock().size(); i++) {
        Entity* temp_entity = (currentCell->getBlock().at(i)->getEntity().get());
        Player* PC = dynamic_cast<Player*>(temp_entity);
        if (PC != nullptr) {
            if (PC->getType() == "Player") {
                // shared pointer and pointer?
                // if enemy dies or not
                if (HP <= 0) {
                    kill(PC);
                } else {
                    attackPlayer(PC);
                }
                return;
            }
        }
        moveRandom();
    }
};

void Enemy::kill(Player* PC) {
    if (this->getHP() <= 0) {
        setHP(0);
        // 1 gold per enemy dead
        PC->setGold(PC->getGold() + 1);
        // unwind myself from cell;
        currentCell->setEntity(nullptr);
        // if I'm compass holder:
        if (stair != nullptr) {
            currentCell->setEntity(make_shared<Entity>(Compass(stair)));
        }
    } else {
        return;
    }
};
