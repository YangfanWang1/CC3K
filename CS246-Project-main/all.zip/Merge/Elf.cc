# include "Elf.h"

Elf::Elf(bool hard,Cell* currentCell):
Player{100,20,30,nullptr,hard,currentCell}{
    baseatk = 20;
    basedef = 30;
    maxhp = 100;
}

Elf::~Elf(){};
