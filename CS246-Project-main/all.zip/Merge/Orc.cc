# include "Orc.h"

Orc::Orc(bool hard,Cell* currentCell):
Player{180,30,25,nullptr,hard,currentCell}{}

int Orc::getGold(){
    return gold/2;
}

Orc::~Orc(){};
