// This module implements a Floor class which manages Chamber and Cell objects.

#ifndef __FLOOR_H__
#define __FLOOR_H__
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <memory>
#include <typeinfo>
#include "Chamber.h"
#include "Cell.h"

// Board dimensions.
const int board_width = 79;
const int board_height = 25;

class Floor {
    private:
        std::vector<std::shared_ptr<Chamber>> chambers; // Store Chambers.
        std::vector<std::shared_ptr<Cell>> cells;       // Store Cells.
    public:
        // Basic Constructor.
        Floor();

        // Accessor for Chambers.
        std::vector<std::shared_ptr<Chamber>> getChambers() const;
        // Accessor for Cells.
        std::vector<std::shared_ptr<Cell>> getCells() const;

        // Generate new Floor, resets layout and Entities given current floor number (0 to 4, inclusive) and reference file.
        // If Player character location is specified in input file, returns Cell * for location. Otherwise, nullptr.
        Cell * generate(int floorNum, std::string filename = "defaultfloor.txt", int seed = 0);
        // Update existing Floor cell-by-cell.
        void update();

        // Basic Destructor.
        ~Floor();

        // Display given Floor to output.
        friend std::ostream &operator<<(std::ostream &out, const Floor &f);
};

#endif
