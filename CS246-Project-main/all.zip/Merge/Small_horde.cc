#include "Small_horde.h"

Small::Small(Entity* protector, bool hard, Cell* currentCell):
    Treasure{2,protector,hard,currentCell}{}