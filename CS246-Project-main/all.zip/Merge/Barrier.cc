#include "Barrier.h"

//the protector of barrier should be dragon, so once it's killed, it will unwind itself and make barrier's protector to null.
void Barrier::acquire(Player* PC){
        PC->setBarrier(true);
        kill();
    }
