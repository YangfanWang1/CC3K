#include "Normal_horde.h"

//worth of 1
Normal::Normal(Entity* protector, bool hard, Cell* currentCell):
    Treasure(1 ,protector,hard,currentCell){}