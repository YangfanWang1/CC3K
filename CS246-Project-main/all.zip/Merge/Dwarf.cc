# include "Dwarf.h"

Dwarf::Dwarf(bool hard,Cell* currentCell):
Player{100,20,30,nullptr,hard,currentCell}{
    basedef = 30;
    baseatk = 20;
    maxhp = 100;
}

int Dwarf::getGold(){
    return gold*2;
}

Dwarf::~Dwarf(){};
