# include "Troll.h"
using namespace std;

Troll::Troll(bool hard,Cell* currentCell, Cell* stair):
Enemy{120,25,25,nullptr,hard,currentCell,stair}{}

Troll::~Troll(){};
