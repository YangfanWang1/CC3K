# ifndef ELF_H
# define ELF_H

# include "Player.h"

class Elf:public Player{
    public:
        Elf(bool hard,Cell* currentCell);
        ~Elf();
};

# endif
