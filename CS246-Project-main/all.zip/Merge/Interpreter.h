// This module implements an Interpreter class which manages the game.

#ifndef __INTERPRETER_H__
#define __INTERPRETER_H__
#include <memory>
#include <iostream>
#include "Floor.h"
#include "Player.h"
#include "Potion.h"
#include "Cell.h"

class Interpreter {
    private:
        int floorNum;                         // Tracks which floor the player is on.
        std::unique_ptr<Floor> level;         // Stores the current Floor.
        std::shared_ptr<Player> player;       // Stores a pointer to the Player.
        int seed;                             // Stores the seed for randomization.
    public:
        // Basic Constructor.
        Interpreter(int seed);

        // Executes the given command for the player by calling the appropriate methods.
        void command(std::string cmd);

        // Starts new game or restarts existing game. Everything is reset.
        // Should also set values for fields [level] and [player] once floor is generated.
        void init();
        // Updates all Entities (primarily Enemies) on the floor.
        void update();
        // Displays the game to output (Should call out << Floor as part of this process).
        void display();

        // Moves the player in the direction specified by the input string.
        void movePlayer(std::string direction);
        // Uses the potion given on the player.
        void usePotion(Potion *p);
        // Proceeds to the next floor. Updates floorNum.
        void nextFloor();
    
        // Exits the game.
        void quit();

        // Basic Destructor.
        ~Interpreter();
};

#endif
