# ifndef DRAGON_H
# define DRAGON_H

# include "Enemy.h"

class Dragon:public Enemy{
    Cell* aggroTrigger;
    public:
        Dragon(bool hard=false,Cell* currentCell=nullptr, Cell* stair=nullptr);
        void setAggroTrigger(Cell *cell);
        // create_barrier randomly 
        void create_barrier();
        void kill(Player*) override;
        void update() override;
        ~Dragon();
};

# endif
