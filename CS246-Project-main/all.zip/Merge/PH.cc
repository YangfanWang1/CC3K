#include "PH.h"

#include "Elf.h"
class Player;

PH::PH() : Potion{"Poison Health"} {}

// potion is diffent, after kill that makes it unwind from cell, it will call dtor by itself.
void PH::apply(Player* PC) {
    Elf* check = dynamic_cast<Elf*>(PC);
    if (check != nullptr) {
        if(PC->getHP()+10 <= PC->getMaxHP()){
        PC->setHP(PC->getHP() + 10);
        }
    } else {
        PC->setHP(PC->getHP() - 10);
    }
    kill();
}
