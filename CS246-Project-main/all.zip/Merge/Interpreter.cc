#include <memory>
#include <iostream>
#include "Floor.h"
#include "Player.h"
#include "Potion.h"
#include "Cell.h"
#include "Interpreter.h"
using namespace std;

Interpreter::Interpreter(int seed) : floorNum{0}, level{nullptr}, player{nullptr}, seed{seed} {}

void Interpreter::init() {
    return;
}

void Interpreter::command(string cmd) {
    // This method should probably call other Interpreter methods.
    // When action is completed, should also call display() and then output what just occured due to the current command.
    return;
}

void Interpreter::update() {
    level->update();
    // Method may(?) need to do more?
}

void Interpreter::display() {
    cout << *(level);
    // Display other stats below main game board here.
    // Does not need to figure out what the latest action is (.command() method will call this function and .command() can handle displaying of latest action)
}

void Interpreter::movePlayer(string direction) {
    return;
}

void Interpreter::usePotion(Potion *p) {
    return;
}

void Interpreter::nextFloor() {
    return;
}

void Interpreter::quit() {
    return;
}

Interpreter::~Interpreter() {}
