#include "BA.h"
class Player;

BA::BA() : Potion{"Boost ATK"} {}
void BA::apply(Player* PC) {
    PC->setATK(PC->getATK() + 10);
    kill();
}
// std::ostream& operator<<(std::ostream& out, BA& p) {
//     out << "P";
//     return out;
// }
