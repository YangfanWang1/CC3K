#ifndef H_NORMAL_H
#define H_NORMAL_H
#include "Treasure.h"

class Normal : public Treasure {
   public:
     Normal(Entity* protector, bool hard, Cell* currentCell);
};
#endif
