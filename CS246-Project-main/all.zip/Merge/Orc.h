# ifndef ORC_H
# define ORC_H

# include "Player.h"

class Orc:public Player{
    public:
        Orc(bool hard,Cell* currentCell);
        int getGold() override;
        ~Orc();
};

# endif
