# ifndef HUMAN_H
# define HUMAN_H

# include "Player.h"

class Human:public Player{
    public:
        Human(bool hard=false,Cell* currentCell=nullptr);
        ~Human();
};

# endif
