#include "WA.h"
#include "Elf.h"
class Player;

WA::WA():Potion{"Wound ATK"}{}

void WA::apply(Player* PC){
  Elf* check=dynamic_cast<Elf*>(PC);
    if(check!=nullptr){
        PC->setHP(PC->getHP()+10);
    }
    else{
    PC->setATK(PC->getATK()-10);
    }
    kill();
}
