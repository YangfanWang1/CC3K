#ifndef H_WD_H
#define H_WD_H
#include "Potion.h"

class WD : public Potion {
    WD();
    void apply(Player* PC) override;
    // friend std::ostream& operator<<(std::ostream& out, WD& p);
};
#endif
