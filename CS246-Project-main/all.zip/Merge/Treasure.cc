#include "Treasure.h"



Treasure::Treasure(int value):value{value}{}

int Treasure::getValue(){
    return value;
}