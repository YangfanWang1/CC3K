#include "WD.h"

#include "Elf.h"
WD::WD() : Potion{"Wound Def"} {}

void WD::apply(Player* PC) {
    Elf* check = dynamic_cast<Elf*>(PC);
    if (check != nullptr) {
        PC->setHP(PC->getHP() + 10);
    } else {
        PC->setDEF(PC->getDEF() - 10);
    }
    kill();
}
