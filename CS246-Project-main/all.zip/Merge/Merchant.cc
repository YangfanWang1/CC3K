#include "Merchant.h"

#include <iostream>
#include <memory>

#include "Merchant_horde.h"
#include "Player.h"
bool Merchant::M_hostile = false;

Merchant::Merchant(bool hard, Cell* currentCell, Cell* stair) : Enemy{30, 70, 5, nullptr, hard, currentCell, stair} {};

std::string Merchant::getType() {
    return "Merchant";
}
void Merchant::set_hostile(bool hostile) {
    M_hostile = hostile;
}

std::ostream& operator<<(std::ostream& out, Merchant& m) {
    out << "M";
    return out;
}

void Merchant::update() {
    Entity::seed++;
    if (M_hostile == true) {
        for (int i = 0; i < currentCell->getBlock().size(); i++) {
            Entity* temp_entity = (currentCell->getBlock().at(i)->getEntity().get());
            Player* PC = dynamic_cast<Player*>(temp_entity);
            if (PC != nullptr) {
                if ((PC->getType() == "Player")) {
                    attackPlayer(PC);
                    return;
                }
            }
        }
    }
    moveRandom();
};

void Merchant::purchasePotion(Player* PC, std::string Potion) {
    std::cout << "yooooo, merchant can't sell now!" << std::endl;
}

void Merchant::kill() {
    // unwind myself from cell and get it to horde
    
    if (stair != nullptr) {
            currentCell->setEntity(std::make_shared<Entity>(Compass(stair)));
        }
    else{
    currentCell->setEntity(std::make_shared<Merchant_horde>(Merchant_horde(protector,hard,currentCell)));
    }
}
