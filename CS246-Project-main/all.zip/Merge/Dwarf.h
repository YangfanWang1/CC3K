# ifndef DWARF_H
# define DWARF_H

# include "Player.h"

class Dwarf:public Player{
    public:
        Dwarf(bool hard,Cell* currentCell);
        int getGold() override;
        ~Dwarf();
};

# endif
