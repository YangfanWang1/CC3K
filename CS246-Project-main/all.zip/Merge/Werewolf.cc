# include "Werewolf.h"
using namespace std;

Werewolf::Werewolf(bool hard,Cell* currentCell, Cell* stair):
Enemy{50,25, 25,nullptr,hard,currentCell,stair}{}

Werewolf::~Werewolf(){};
