#include "Merchant_horde.h"


Merchant_horde::Merchant_horde(Entity* protector, bool hard, Cell* currentCell):
    Treasure(4 ,protector,hard,currentCell){}
