# include "Goblin.h"
using namespace std;

Goblin::Goblin(bool hard,Cell* currentCell, Cell* stair):
Enemy{70,5,10,nullptr,hard,currentCell,stair}{}

Goblin::~Goblin(){};
