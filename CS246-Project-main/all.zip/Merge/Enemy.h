#ifndef ENEMY_H
#define ENEMY_H

#include <memory>
#include <string>

#include "Entity.h"

class Player;
class Cell;

class Enemy : public Entity {
   protected:
    Cell* stair;

   public:
    Enemy(int HP, int ATK, int DEF, Entity* protector, bool hard, Cell* currentCell, Cell* stair);
    virtual std::string getType() = 0;
    void moveRandom();
    void attackPlayer(Player*);
    // dragon and merchant override
    virtual void update();
    // Dragon and Merhcant override, PC does not get gold from them, and merchant drop merchant horde
    virtual void kill(Player*);
    virtual ~Enemy() = default;
};

#endif
