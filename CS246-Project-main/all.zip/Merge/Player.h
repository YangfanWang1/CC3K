#ifndef PLAYER_H
#define PLAYER_H
#include <memory>
#include <string>
#include <vector>

#include "Enemy.h"
#include "Entity.h"
#include "Treasure.h"

class Player : public Entity {
   protected:
    bool barrier_suit;
    int baseatk;
    int basedef;
    int maxhp;
    int gold;

   public:
    Player(int HP, int ATK, int DEF, Entity* protector, bool hard, Cell* currentCell);
    // modify my treasure
    int getMaxHP();
    void collectTreasure(Treasure* t);
    bool getBarrier();
    void setBarrier(bool a);
    virtual int getGold();
    void setGold(int n);
    std::string getType() override;
    void resetStats();
    void attackEnemy(Enemy* e);
    virtual ~Player() = default;
};

#endif
