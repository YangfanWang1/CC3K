#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <memory>
#include <typeinfo>
#include "Chamber.h"
#include "Cell.h"
#include "Floor.h"
#include "Entity.h"
#include "Merchant_horde.h"
#include "Dragon_horde.h"
using namespace std;

Floor::Floor() {}

vector<shared_ptr<Chamber>> Floor::getChambers() const {
    return chambers;
}

vector<shared_ptr<Cell>> Floor::getCells() const {
    return cells;
}

Cell * Floor::generate(int floorNum, string filename, int seed) {
    std::vector<std::shared_ptr<Cell>> tempCells;
    Cell *playerLoc = nullptr;
    char inp = ' ';
    bool populated = false;
    ifstream layout {filename};
    // Discard any input from previous floors and get to current floor.
    for (int i = 0; i < board_height * board_width * floorNum; ++i) {
        layout >> inp;
    }
    // Read in input from given file and add Cells accordingly.
    for (int i = 0; i < board_height; ++i) {
        for (int j = 0; j < board_width; ++j) {
            layout >> inp;
            int cellType = OPEN;                           // By default, Cells are OPEN (A regular cell).
            bool occupied = true;                          // Check if Entity exists on Cell.
            for (int k = 0; k < cellDisplay.size(); ++k) { // Check input Cell type.
                if (inp == cellDisplay[k]) {
                    cellType = k;
                    occupied = false;
                }
            }
            tempCells.emplace_back(make_shared<Cell>(j, i, cellType));
            // If there is an Entity on the tile, generate and bind it.
            if (occupied) {
                populated = true;
                // !!!!! Generate Entity via tempCells[i * board_width + j]->setEntity(make_shared<ENTITYTYPE>(PARAMETERS NEEDED));
                if (inp == '@') {
                    playerLoc = tempCells[i * board_width + j].get();
                    // Don't do anything else for player. Race is picked and player is created
                    //   in Interpreter.init(), we just retrieve the Cell location for now.
                } else if (inp == 'V') {
                    //
                } else if (inp == 'W') {
                    //
                } else if (inp == 'N') {
                    //
                } else if (inp == 'M') {
                    //
                } else if (inp == 'D') {
                    //
                } else if (inp == 'X') {
                    //
                } else if (inp == 'T') {
                    //
                } else if (inp == '0') {
                    //
                } else if (inp == '1') {
                    //
                } else if (inp == '2') {
                    //
                } else if (inp == '3') {
                    //
                } else if (inp == '4') {
                    //
                } else if (inp == '5') {
                    //
                } else if (inp == '6') {
                    //
                } else if (inp == '7') {
                    //
                } else if (inp == '8') {
                    //tempCells[i * board_width + j]->setEntity(make_shared<Merchant_horde>());
                } else if (inp == '9') {
                    //tempCells[i * board_width + j]->setEntity(make_shared<Dragon_horde>());
                }
            }
        }
    }
    cells = tempCells;
    // For each cell, construct list of all cells in block and attach it to Cell.
    for (int i = 0; i < board_height; ++i) {
        for (int j = 0; j < board_width; ++j) {
            std::vector<Cell *> newBlock{};
            for (int k = i - 1; k < i + 2; ++k) {
                for (int l = j - 1; l < j + 2; ++l) {
                    // If neighbouring cell is in bounds, add as a neighbour.
                    if (!(i == k && j == l) && k >= 0 && k < board_height && l >= 0 && l < board_width && 
                        cells[k * board_width + l]->getType() != SOLID && 
                        cells[k * board_width + l]->getType() != H_WALL && 
                        cells[k * board_width + l]->getType() != V_WALL) {
                        newBlock.emplace_back(cells[k * board_width + l].get());
                    }
                }
            }
            cells[i * board_width + j]->setBlock(newBlock);
        }
    }
    // If the layout is not already populated, randomly populate it with Entities.
    if (!populated) {
        for (int i = 0; i < board_height * board_width; ++i) {
            // !!!!! Do stuff to randomly populate cells.
        }
    }
    // Create list of chambers and link cells.
    std::vector<std::shared_ptr<Chamber>> tempChambers;
    for (int i = 0; i < 5; i ++) {
        tempChambers.emplace_back(make_shared<Chamber>(i));
    }
    // !!!!! Create list of chambers and link the Cells.
    //tempChambers[0]->setCells(SOME VECTOR LIST OF CELLS);
    //tempChambers[1]->setCells(SOME VECTOR LIST OF CELLS);
    //tempChambers[2]->setCells(SOME VECTOR LIST OF CELLS);
    //tempChambers[3]->setCells(SOME VECTOR LIST OF CELLS);
    //tempChambers[4]->setCells(SOME VECTOR LIST OF CELLS);
    chambers = tempChambers;

    // Lastly, just return the Player Cell we found prior (if one exists).
    return playerLoc;
}

void Floor::update() {
    for (int i = 0; i < board_height; ++i) {
        for (int j = 0; j < board_width; ++j) {
            Entity *ent = cells[i * board_width + j]->getEntity().get();
            if (ent) {
                ent->update();
            }
        }
    }
}

Floor::~Floor() {}

ostream &operator<<(ostream &out, const Floor &f) {
    // Display each cell in the floor one-by one.
    for (int i = 0; i < board_height; ++i) {
        for (int j = 0; j < board_width; ++j) {
            out << f.cells[i * board_width + j];
        }
        out << endl;
    }
    return out;
}
