#ifndef H_BA_H
#define H_BA_H
#include "Entity.h"
#include "Potion.h"
class BA : public Potion {
    // friend std::ostream& operator<<(std::ostream& out, BA& p);
    BA();
    void apply(Player* PC) override;
};
#endif
