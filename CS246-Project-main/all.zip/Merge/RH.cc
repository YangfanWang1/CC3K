#include "RH.h"
class Player;

RH::RH() : Potion{"Restore Health"} {}

// potion is diffent, after kill that makes it unwind from cell, it will call dtor by itself.
void RH::apply(Player* PC) {
    if((PC->getHP()+10)<=getMaxHP()){
    PC->setHP(PC->getHP() + 10);
    }

    kill();
}
