#include <iostream>
#include <vector>
#include <memory>
#include "Cell.h"
#include "Entity.h"
using namespace std;

Cell::Cell(int x, int y, int type) : x{x}, y{y}, type{type}, entityHere{nullptr}, hidden{false} {}

int Cell::getX() const {
    return x;
}

int Cell::getY() const {
    return y;
}

int Cell::getType() const {
    return type;
}

vector<Cell *> Cell::getBlock() const {
    return block;
}

void Cell::setBlock(std::vector<Cell *> newBlock) {
    block = newBlock;
}

vector<Cell *> Cell::getWalkableBlock() const {
    vector<Cell *> walkable;
    for (int i = 0; i < block.size(); ++i) {
        if (block[i]->getType() == OPEN || block[i]->getType() == STAIRS) {
            walkable.emplace_back(block[i]);
        }
    }
    return walkable;
}

void Cell::reveal() {
    hidden = false;
}

std::shared_ptr<Entity> Cell::getEntity() const {
    return entityHere;
}

void Cell::setEntity(std::shared_ptr<Entity> newEntity) {
    entityHere = newEntity;
}

void Cell::transferEntity(Cell *other) {
    Cell * temp = nullptr;
    temp = entityHere->getCurrentCell();
    entityHere->setCurrentCell(other->entityHere->getCurrentCell());
    other->entityHere->setCurrentCell(temp);
    entityHere.swap(other->entityHere);
}

Cell::~Cell() {}

ostream &operator<<(ostream &out, const Cell &c) {
    // If an entity exists on the cell, display it instead. Otherwise, display the cell.
    if (c.entityHere.get()) {
        //out << *(c.entityHere.get());  //UNCOMMENT THIS OUT WHEN << IS IMPLEMENTED FOR ENEMIES.
    } else {
        // Add special colors for each cell type later.
        if (c.type == SOLID) {
            out << cellDisplay[c.type];
        } else if (c.type == OPEN) {
            out << cellDisplay[c.type];
        } else if (c.type == H_WALL) {
            out << cellDisplay[c.type];
        } else if (c.type == V_WALL) {
            out << cellDisplay[c.type];
        } else if (c.type == DOORWAY) {
            out << cellDisplay[c.type];
        } else if (c.type == PASSAGE) {
            out << cellDisplay[c.type];
        } else if (c.type == STAIRS) {
            if (c.hidden) {
                out << cellDisplay[OPEN];
            } else {
                out << cellDisplay[c.type];
            }
        }
    }
    return out;
}
