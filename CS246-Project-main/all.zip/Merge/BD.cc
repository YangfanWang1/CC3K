#include "BD.h"

BD::BD():Potion{"Boost Def"}{}
void BD::apply(Player* PC){
    PC->setDEF(PC->getDEF()+10);
    kill();
}
