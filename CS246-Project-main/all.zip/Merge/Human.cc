# include "Human.h"


Human::Human(bool hard,Cell* currentCell):
Player{140,20,20,nullptr,hard,currentCell}{
    baseatk = 20;
    basedef = 20;
    maxhp = 140;
}

Human::~Human(){};
