# include "Troll.h"
using namespace std;

Troll::Troll(int HP,int ATK,int DEF, Entity* protector, bool hard,Cell* currentCell, bool compassHolder){};

void Troll::attackPlayer(Player*){};

Troll::~Troll(){};
