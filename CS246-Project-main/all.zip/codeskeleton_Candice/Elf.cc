# include "Elf.h"

Elf::Elf(int HP,int ATK,int DEF, Entity* protector, bool hard,Cell* currentCell){};

Elf::~Elf(){};
