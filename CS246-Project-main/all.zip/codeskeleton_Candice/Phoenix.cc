# include "Phoenix.h"
using namespace std;

Phoenix::Phoenix(int HP,int ATK,int DEF, Entity* protector, bool hard,Cell* currentCell, bool compassHolder){};

void Phoenix::attackPlayer(Player*){};

Phoenix::~Phoenix(){};
