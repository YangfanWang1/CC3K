# CS246-Project

## CC3K - A group project made by Howard Zhu, Chris Qin, and Candice Wang

Introduction
The main components of the project are floors and entities. There are five floors and five chambers per floor. Entities are composed of treasures, items, potions, enemies and players. Enemies, treasures and potions are generated on the floors, and the player can move on the floor to slay enemies to get treasures or items or to pick up treasure and potions. Enemies can move one square randomly within the confines of the chamber.
When implementing the game, we have two controller classes. We use the Interpreter class to control all basic features of Floor, Chamber, and Cell class, whereas the Entity class controls all basic features happening on Floor.
